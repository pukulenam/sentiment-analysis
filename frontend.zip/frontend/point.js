// var request = require('request');
// var options = {
//   'method': 'POST',
//   'url': 'http://34.128.75.233:8080/api/v1/converting',
//   'headers': {
//     'Content-Type': 'application/json'
//   },
//   body: JSON.stringify({
//     "penulis": "string",
//     "sampul": "string",
//     "sumberGb": "string",
//     "referensi": "string",
//     "finansial": "string",
//     "judul": "string",
//     "kategory": "finansial",
//     "news": "mjml"
//   })

// };
// request(options, function (error, response) {
//   if (error) throw new Error(error);
//   console.log(response.body);
// });
var request = require("request");

request.post({
    "headers": { "content-type": "application/json" },
    "url": "http://34.128.75.233:8080/api/v1/converting",
    "body": JSON.stringify({
        "penulis": "ds",
        "sampul": "y",
        "sumberGb": "fd",
        "referensi": "ggdfg",
        "finansial": "gsdf",
        "judul": "dfeg",
        "kategory": "finansial",
        "news": "ita"
      })
}, (error, response, body) => {
    if(error) {
        return console,log(error);
    }
    // console.log(JSON.parse(body));
    
});