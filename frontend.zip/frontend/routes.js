var express = require("express");
var request = require('request');
var bodyParser = require('body-parser');
var app = express()

// create application/json parser
var jsonParser = bodyParser.json()

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })
var router = express.Router();

router.get("/", function (req, res) {
    console.log("Hello i'm on the start page here");
    res.render("index")
});

router.get("/convert", function (req, res) {

    res.render("convert")
});
// router.post("/convert-post", jsonParser, function (req, res) {
//     request.post({
//         "headers": { "content-type": "application/json" },
//         "url": " http://34.101.189.116:5000/api/text-sentiment-analysis",
//         "body": JSON.stringify(req.body)
//     }, (error, response, body) => {
//         if (error) {
//             return res.send(error);
//         }
//         const data = res.send(JSON.parse(body));
//         alert(data)
//     });

// });

router.post("/convert", jsonParser, function (req, res) {
    //console.log(req)
    request.post({
        "headers": { "content-type": "application/json" },
        "url": "http://34.128.75.233:8080/api/v1/converting",
        "body": JSON.stringify(req.body)
    }, (error, response, body) => {
        if (error) {
            return res.send(error);
        }
        res.render("notifikasi");
        //res.send(JSON.parse(body));
    });
})


module.exports = router;