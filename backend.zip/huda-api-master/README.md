# Documentation

You can open `http://localhost:8080/api/v1/docs` after app running to dee documentation
